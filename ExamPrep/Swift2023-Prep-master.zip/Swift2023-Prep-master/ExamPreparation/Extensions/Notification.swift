//
//  Notification.swift
//  ExamPreparation
//
//  Created by Martin Kuvandzhiev on 2.02.23.
//

import Foundation

extension Notification.Name {
    static let dataUpdatedNotification = Notification.Name("dataUpdatedNotification")
}
