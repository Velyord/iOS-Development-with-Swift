//
//  ViewController2.swift
//  yoansBudgetApp
//
//  Created by macdev on 11.01.23.
//

import UIKit

class ViewController2: UIViewController {
    @IBOutlet weak var generateButton: UIButton!
    
    @IBOutlet weak var myImageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    var images:[String] = ["born2party", "chillin", "christian_dubstep", "dog", "horse", "lion", "lit", "owl", "violin", "whale"]
    
    @IBAction func generateImage(_ sender: UIButton) {
        myImageView.image = UIImage(named: "\(images[Int.random(in: 0..<10)])")
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
