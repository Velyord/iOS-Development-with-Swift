//
//  ViewController.swift
//  yoansBudgetApp
//
//  Created by macdev on 10.01.23.
//

import UIKit

class ViewController3: UIViewController {

    @IBOutlet weak var cenaNaGorivo: UITextField!
    @IBOutlet weak var otstupkaNaCenata: UITextField!
    @IBOutlet weak var litriNa100km: UITextField!
    @IBOutlet weak var kmDoDestinaciq: UITextField!
    @IBOutlet weak var speedSlider: UISlider!
    @IBOutlet weak var resultsLabel: UILabel!
    @IBOutlet weak var finalResultsLabel: UILabel!
    @IBOutlet weak var vDvePosokiSwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    @IBAction func sliderValue(_ sender: Any) {
        let speedSliderString = String(format: "%.0f", self.speedSlider.value)
        self.resultsLabel.text = "\(speedSliderString)"
    }

    @IBAction func izchisliButton(_ sender: Any) {
        let stringCenaNaGorivo = cenaNaGorivo.text!
        let stringOtstupkaNaCenata = otstupkaNaCenata.text!
        let stringLitriNa100km = litriNa100km.text!
        let stringKmDoDestinaciq = kmDoDestinaciq.text!
        
        
        if let doubleCenaNaGorivo = Double(stringCenaNaGorivo), let doubleOtstupkaOtCenata = Double (stringOtstupkaNaCenata), let doubleLitriNa100km = Double(stringLitriNa100km), let doubleKmDoDestinaciq = Double(stringKmDoDestinaciq) {
            let gorivoKrainaCena = doubleCenaNaGorivo-doubleOtstupkaOtCenata
            let cenaNaKm = doubleLitriNa100km / 100 * gorivoKrainaCena
            var cenaNaDestination = doubleKmDoDestinaciq * cenaNaKm
            var multiplier = 1.0
            if self.vDvePosokiSwitch.isOn {
                multiplier = 2.0
            }
            cenaNaDestination *= multiplier
            self.finalResultsLabel.text = String(format: "%.2f", cenaNaDestination)
        } else {
            finalResultsLabel.text = "Грешка!"
        }
    }
}
